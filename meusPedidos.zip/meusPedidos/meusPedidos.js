function carregarProdutos(){
    
    var conteudoPrincipal = document.getElementById("divMeusPedidos");
    $("#divProdutos").children(".divEditar").remove()
    var htmlProdutos = "";

    for(var i=0; i<loja.length; i++){
        var ProdutoAtual = loja[i];
        var data = new Date();
        var cartaoProduto = `
                <div class="row m-3" id="${ProdutoAtual.id}">
                    <div class="col-sm-3 col-4">
                        <img src="img/pacai.png" class="imgMain" alt="">
                    </div>

                    <div class="col-sm-6 col-4">
                        <div class="row">
                            <div class="col-sm-12">
                                <span class="spProdutos">
                                    ${ProdutoAtual.nome}
                                </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <span><strong>Sabor</strong>: ${ProdutoAtual.sabor.reduce(
                                    (accumulator) => {
                                        return accumulator;
                                    })}</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <span>${contemTamanho(ProdutoAtual.tamanho)}</span>
                            </div>
                        </div>
                    </div> 
                    <div class="col-sm-3 col-4">
                        <span><strong>Valor</strong>: ${ProdutoAtual.valor}</span>
                        <div class="row">
                            <div class="col-sm-12 mt-4">
                                <span><strong>Data</strong>:${data.toLocaleDateString()}</span>
                            </div>
                        </div>                    
                    </div>
                </div>
                `;
        htmlProdutos += cartaoProduto;
    }

    conteudoPrincipal.innerHTML += htmlProdutos;  
    localStorage.setItem('produtos', JSON.stringify(loja));  
    localStorage.setItem("id_max", id_produto);
}

var loja = JSON.parse(localStorage.getItem('produtos'));
var id_produto = JSON.parse(localStorage.getItem("id_max"))

if(!loja || loja==null){
    console.log(loja)
    loja = new Array({
        nome : 'Suco Natural', sabor: ['Laranja', 'Maracujá', 'Maçã', 'Uva'], tamanho: ['100ml', '250ml', '350ml'], arquivo: 'img/vitamina-de-frutas-2.jpg', id: '0',valor: '4,50 R$', edicao:false}
        ,{ 
        nome: 'Bombons', sabor: ['Morango', 'Maracujá', 'Chocolate', 'Amargo'], arquivo: 'img/bombons-g.jpg', id: '1',valor: '3,50 R$', edicao:false},
        { 
        nome: 'Bolo de Pote', sabor: ['Doce de Leite', 'Chocolate', 'Ninho', 'Morango'], tamanho: ['Pequeno', 'Médio', 'Grande'], arquivo: 'img/sabores-de-bolo-no-pote-mais-vendidos-1200x800.jpg', id: '2', valor: '4,00 R$', edicao:false},
        { 
        nome: 'Coxinha', sabor: ['Frango', 'Frango c/ Catupiry', 'Queijo', 'Calabresa'], tamanho: ['Pequena', 'Média', 'Grande'], arquivo: 'img/coxinha-4161592_1280.jpg', id: '3', valor: '2,50 R$', edicao:false
    });
}

id_produto = ( id_produto == null ? (Number(loja.length)): id_produto);

$(document).ready(function(){

    carregarProdutos();
    // $(".tamanhos").hide()

})

function contemTamanho(array,tamanho){

    var ret =  (array?.indexOf(tamanho) != undefined && array?.indexOf(tamanho) != -1 ) ? 
                'selected' 
                :
                'multiple ';  
    return ret;
}